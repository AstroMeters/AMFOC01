package fastmath_test

// A global result variables to trick the compiler during benchmarks into not
// optimizing the functions out.
var result8 uint8
var result16 int16
