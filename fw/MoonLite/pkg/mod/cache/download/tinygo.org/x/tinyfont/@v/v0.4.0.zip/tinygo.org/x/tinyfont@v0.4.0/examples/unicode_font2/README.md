# unicode\_font2

Testing with pyportal.  

```
$ tinygo build -o app.uf2 -target pyportal -size short ./examples/unicode_font2
```

![](unicode_font2.jpg)
