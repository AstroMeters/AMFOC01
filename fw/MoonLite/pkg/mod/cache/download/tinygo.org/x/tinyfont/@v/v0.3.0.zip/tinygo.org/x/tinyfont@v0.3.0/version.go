package tinyfont

// Version returns a user-readable string showing the version of the tinyfont package
// for support purposes.
//
// Update this value before release of new version of software.
const Version = "0.3.0"
