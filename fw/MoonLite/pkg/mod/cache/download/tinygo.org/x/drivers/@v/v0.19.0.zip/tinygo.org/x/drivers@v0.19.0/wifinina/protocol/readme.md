WiFiNINA protocol
=================

