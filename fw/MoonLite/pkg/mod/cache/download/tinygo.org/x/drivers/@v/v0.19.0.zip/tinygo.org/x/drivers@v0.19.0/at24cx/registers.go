package at24cx

// The I2C address which this device listens to.
const Address = 0x57
