# unicode\_font

Testing with pyportal.  

```
$ tinygo build -o app.uf2 -target pyportal -size short ./examples/unicode_font
```

![](unicode_font.jpg)
