package common

const VERSION = "0.0.1"

func CurrentVersion() string {
	return VERSION
}
