//go:build arduino
// +build arduino

package main

import "machine"

// Replace neo and led in the code below to match the pin
// that you are using if different.
var neo = machine.D2
var led = machine.LED
